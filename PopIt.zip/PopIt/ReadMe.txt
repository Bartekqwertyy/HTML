Witam, nie mogłem znaleźć czcionki odpowiadającej tej z pliku result.txt więc zamieściłem inną, 
starałem się ją dopasować do strony, Pozdrawiam :)